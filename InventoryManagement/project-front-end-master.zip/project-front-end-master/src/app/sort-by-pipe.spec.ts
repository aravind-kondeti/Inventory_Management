import { SortByPipe } from './sort-by-pipe';

describe('SortByPipe', () => {
  it('should create an instance', () => {
    expect(new SortByPipe()).toBeTruthy();
  });
});
