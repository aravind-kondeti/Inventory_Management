import { OrderbyPipe } from './orderby-pipe';

describe('OrderbyPipe', () => {
  it('should create an instance', () => {
    expect(new OrderbyPipe()).toBeTruthy();
  });
});
