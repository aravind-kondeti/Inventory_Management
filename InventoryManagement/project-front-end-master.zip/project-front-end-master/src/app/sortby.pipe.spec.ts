import { SortByPipe } from './sortby.pipe';

describe('SortbyPipe', () => {
  it('create an instance', () => {
    const pipe = new SortByPipe();
    expect(pipe).toBeTruthy();
  });
});
