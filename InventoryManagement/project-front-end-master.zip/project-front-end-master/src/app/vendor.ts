export class Vendor {
    vendorId:Number;
    companyName:String;
    address:String;
    area:String;
    contact:String;
    city:String;
    vendortype:String;
}
