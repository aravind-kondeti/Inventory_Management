export class InventoryForm {
    public qty:Number;
    public vendorId:Number;
    public productId:Number;
    public vendortype:String;
}
