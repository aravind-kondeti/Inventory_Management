export class Login {
    uname:string;
    pwd:string;
    role:string;
}
