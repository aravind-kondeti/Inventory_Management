import { Inventorytxn } from './inventorytxn';

describe('Inventorytxn', () => {
  it('should create an instance', () => {
    expect(new Inventorytxn()).toBeTruthy();
  });
});
