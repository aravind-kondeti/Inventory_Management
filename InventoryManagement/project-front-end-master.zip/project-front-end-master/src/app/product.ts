export class Product {
        productId:Number
        productName:String
        productModel:String
        brand:String
        stock:Number
        sellerPrice:Number
        supplierPrice:Number
}
